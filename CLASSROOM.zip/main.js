let classroomCode = "";
let isTeacher = false;

function loginWithGoogle() {
  // Placeholder for Google Auth logic
  alert("Logged in with Google");
  onLogin();
}

function loginWithFacebook() {
  // Placeholder for Facebook Auth logic
  alert("Logged in with Facebook");
  onLogin();
}

function onLogin() {
  document.getElementById('login-section').classList.add('hidden');
  document.getElementById('profile-section').classList.remove('hidden');
  generateRoomCode(); // Simulate classroom code for teacher
}

function generateRoomCode() {
  classroomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  document.getElementById('room-code-display').innerText = classroomCode;
}

function logout() {
  alert("Logged out successfully!");
  location.reload();
}

function showStudents() {
  document.getElementById('profile-section').classList.add('hidden');
  document.getElementById('students-section').classList.remove('hidden');

  // Example: Populate student attendance (static for now)
  const students = [
    { name: "John Doe", status: "Present" },
    { name: "Jane Smith", status: "Absent" },
    ];

  let studentList = document.getElementById('student-list');
  studentList.innerHTML = ''; // Clear the table
  students.forEach(student => {
    let row = `<tr><td>${student.name}</td><td>${student.status}</td></tr>`;
    studentList.innerHTML += row;
  });
}